# Avaliação — Engenharia de Software
**Sistema Integrado de Gestão de Farmácia — MVP Definido pelo Estudante**

Aluno: André Luis Carneiro Filho  
RA: 24000043
Data: 26/03/2026

---

# 1. Definição do MVP
Descreva aqui **qual parte do sistema** foi incluída no seu MVP.  
Explique claramente:

Meu MVP cobre o processo de venda em uma unidade da farmácia, desde a identificação ou cadastro do cliente até a emissão do comprovante, incluindo verificação de estoque e vendas a prazo com geração de contas a receber.

 - Dentro do MVP
 Registro de vendas
 Consulta de produtos
 Verificação de estoque
 Cadastro de clientes
 Emissão de comprovante
 Venda a prazo com geração de contas a receber
 Autorização de venda controlada

- Fora do MVP
 Gestão completa de compras
 Contas a pagar
 Relatórios avançados
 Transferência entre unidades
 Indicadores estratégicos

- Justificativa

O foco foi escolhido por ser o processo mais crítico da farmácia, garantindo valor imediato ao negócio e permitindo validar integração entre estoque, cliente e financeiro.
---

# 2. Regras de Negócio (mínimo: 5)
Liste e descreva **cada RN** de forma clara.

RN01 — Produtos só podem ser vendidos se houver estoque disponível.
RN02 — Toda venda deve atualizar automaticamente o estoque.
RN03 — Clientes devem estar cadastrados para compras a prazo.
RN04 — Vendas a prazo geram automaticamente contas a receber.
RN05 — Medicamentos controlados exigem autorização do farmacêutico.
RN06 — O sistema deve impedir venda com estoque insuficiente.

---

# 3. Requisitos Funcionais (mínimo: 8)
Liste os requisitos funcionais do seu MVP.

RF01 — Consultar produtos por nome, código de barras ou fabricante.
RF02 — Registrar venda de produtos.
RF03 — Verificar estoque automaticamente durante a venda.
RF04 — Permitir cadastro rápido de clientes.
RF05 — Emitir comprovante de venda.
RF06 — Registrar vendas a prazo.
RF07 — Gerar contas a receber automaticamente.
RF08 — Permitir autorização de medicamentos controlados.
RF09 — Atualizar estoque após venda.

---

# 🛡 4. Requisitos Não Funcionais (mínimo: 4)
Liste os RNFs do sistema conforme seu MVP.

RNF01 — O sistema deve ser web e acessível em tempo real.
RNF02 — Deve garantir autenticação e controle de acesso.
RNF03 — Deve responder operações em até 3 segundos.
RNF04 — Deve garantir integridade dos dados em transações.

---

# 5. Casos de Uso (mínimo: 10)
### Inserir **diagrama de casos de uso geral**, demonstrando claramente:

- Casos de Uso

Realizar Venda
Consultar Produto
Verificar Estoque
Cadastrar Cliente
Identificar Cliente
Emitir Comprovante
Registrar Venda a Prazo
Gerar Contas a Receber
Autorizar Venda Controlada
Atualizar Estoque

- Relacionamentos
<<include>>
Realizar Venda → Consultar Produto
Realizar Venda → Verificar Estoque
Realizar Venda → Emitir Comprovante
<<extend>>
Realizar Venda → Cadastrar Cliente
Realizar Venda → Registrar Venda a Prazo
Realizar Venda → Autorizar Venda Controlada

---

# 6. Documentação dos Casos de Uso
Para **cada caso de uso**, utilize o template abaixo:
---

# 6. Documentação dos Casos de Uso

---

## **UC01 — Realizar Venda**

**Ator(es):** Atendente
**Descrição:** Registrar venda de produtos ao cliente
**Pré-condições:** Sistema ativo
**Pós-condições:** Venda registrada e estoque atualizado

### Fluxo Principal

1. Atendente inicia venda
2. Sistema solicita produto
3. Atendente consulta produto
4. Sistema exibe dados
5. Atendente informa quantidade
6. Sistema verifica estoque
7. Sistema calcula total
8. Atendente confirma venda
9. Sistema registra venda
10. Sistema atualiza estoque
11. Sistema emite comprovante

### Fluxos Alternativos / Exceções

* FA01 — Produto não encontrado
* FA02 — Estoque insuficiente

### Relacionamentos

* **Include:** Consultar Produto, Verificar Estoque, Emitir Comprovante
* **Extend:** Cadastrar Cliente, Registrar Venda a Prazo, Autorizar Venda Controlada

---

## **UC02 — Consultar Produto**

**Ator(es):** Atendente
**Descrição:** Buscar produto no sistema
**Pré-condições:** Sistema ativo
**Pós-condições:** Produto exibido ou erro informado

### Fluxo Principal

1. Atendente insere nome, código ou fabricante
2. Sistema realiza a busca
3. Sistema exibe o produto encontrado

### Fluxos Alternativos / Exceções

* FA01 — Produto não encontrado

### Relacionamentos

* **Include:** —
* **Extend:** —

---

## **UC03 — Verificar Estoque**

**Ator(es):** Sistema
**Descrição:** Verificar disponibilidade de produto em estoque
**Pré-condições:** Produto selecionado
**Pós-condições:** Quantidade disponível informada

### Fluxo Principal

1. Sistema consulta o estoque
2. Sistema retorna a quantidade disponível

### Fluxos Alternativos / Exceções

* FA01 — Produto sem estoque

### Relacionamentos

* **Include:** —
* **Extend:** —

---

## **UC04 — Cadastrar Cliente**

**Ator(es):** Atendente
**Descrição:** Registrar novo cliente no sistema
**Pré-condições:** Cliente não cadastrado
**Pós-condições:** Cliente registrado no sistema

### Fluxo Principal

1. Atendente informa os dados do cliente
2. Sistema valida os dados
3. Sistema salva o cliente

### Fluxos Alternativos / Exceções

* FA01 — Dados inválidos

### Relacionamentos

* **Include:** —
* **Extend:** —

---

## **UC05 — Identificar Cliente**

**Ator(es):** Atendente
**Descrição:** Localizar cliente no sistema
**Pré-condições:** Sistema ativo
**Pós-condições:** Cliente identificado ou não encontrado

### Fluxo Principal

1. Atendente informa CPF ou identificador
2. Sistema realiza a busca
3. Sistema exibe os dados do cliente

### Fluxos Alternativos / Exceções

* FA01 — Cliente não encontrado

### Relacionamentos

* **Include:** —
* **Extend:** —

---

## **UC06 — Emitir Comprovante**

**Ator(es):** Sistema
**Descrição:** Gerar comprovante da venda
**Pré-condições:** Venda concluída
**Pós-condições:** Comprovante emitido

### Fluxo Principal

1. Sistema reúne os dados da venda
2. Sistema gera o comprovante
3. Sistema disponibiliza o comprovante

### Fluxos Alternativos / Exceções

* FA01 — Falha na geração do comprovante

### Relacionamentos

* **Include:** —
* **Extend:** —

---

## **UC07 — Registrar Venda a Prazo**

**Ator(es):** Atendente
**Descrição:** Registrar venda com pagamento futuro
**Pré-condições:** Cliente cadastrado
**Pós-condições:** Venda registrada como a prazo

### Fluxo Principal

1. Atendente seleciona opção de venda a prazo
2. Atendente define data de vencimento
3. Sistema registra a venda

### Fluxos Alternativos / Exceções

* FA01 — Cliente não cadastrado

### Relacionamentos

* **Include:** Gerar Contas a Receber
* **Extend:** —

---

## **UC08 — Gerar Contas a Receber**

**Ator(es):** Sistema
**Descrição:** Criar lançamento financeiro de venda a prazo
**Pré-condições:** Venda a prazo realizada
**Pós-condições:** Conta a receber registrada

### Fluxo Principal

1. Sistema cria lançamento financeiro
2. Sistema define valor e vencimento
3. Sistema salva a conta a receber

### Fluxos Alternativos / Exceções

* FA01 — Falha no registro

### Relacionamentos

* **Include:** —
* **Extend:** —

---

## **UC09 — Autorizar Venda Controlada**

**Ator(es):** Farmacêutico
**Descrição:** Autorizar venda de medicamento controlado
**Pré-condições:** Receita apresentada
**Pós-condições:** Venda autorizada ou negada

### Fluxo Principal

1. Farmacêutico analisa a receita
2. Sistema valida informações
3. Farmacêutico autoriza a venda

### Fluxos Alternativos / Exceções

* FA01 — Receita inválida
* FA02 — Venda negada

### Relacionamentos

* **Include:** —
* **Extend:** —

---

## **UC10 — Atualizar Estoque**

**Ator(es):** Sistema
**Descrição:** Atualizar quantidade de produtos após venda
**Pré-condições:** Venda concluída
**Pós-condições:** Estoque atualizado

### Fluxo Principal

1. Sistema subtrai a quantidade vendida
2. Sistema atualiza o estoque
3. Sistema salva os dados

### Fluxos Alternativos / Exceções

* FA01 — Erro na atualização

### Relacionamentos

* **Include:** —
* **Extend:** —

---




